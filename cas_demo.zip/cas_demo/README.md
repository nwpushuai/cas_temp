﻿# cas_demo
Cas单点登录案例

## CAS之 5.2x版本配置数据库访问
http://blog.csdn.net/yelllowcong/article/details/78808607

# 加密
## MD5和SHA1加密
http://blog.csdn.net/yelllowcong/article/details/78809943

## 自定义加密
http://blog.csdn.net/yelllowcong/article/details/78812744

## REST验证