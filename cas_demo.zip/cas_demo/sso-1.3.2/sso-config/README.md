# 启动

```cmd
mvn spring-boot:run
```