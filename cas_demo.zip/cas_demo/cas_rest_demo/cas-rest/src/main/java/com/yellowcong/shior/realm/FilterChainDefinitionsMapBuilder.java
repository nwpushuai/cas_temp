package com.yellowcong.shior.realm;

import java.util.LinkedHashMap;

/**
 * 创建日期:2017年12月17日
 * 创建时间:下午9:39:30
 * 创建者    :yellowcong
 * 机能概要:
 */
public class FilterChainDefinitionsMapBuilder {
	
	
	/**
	 * 获取权限
	 * @return
	 */
	public LinkedHashMap<String, String> loadFilterChainDefinitions(){
		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
		//优先匹配前面的配置，这一点需要注意的
		//设置访问用户list页面需要授权操作
		map.put("/user/error", "anon");
		map.put("/users/user/login", "anon");
		//配置js和img这些静态资源被任何人访问到
		map.put("/resources/img/**", "anon");
		map.put("/resources/js/**", "anon");
		map.put("/user/list", "authc");
    	map.put("/**", "authc");
		return map;
	}
}
