package com.yellowcong.dao;

import java.util.List;
import java.util.Map;

import com.yellowcong.model.User;

/**
 * 创建日期:2017年9月23日 <br/>
 * 创建用户:yellowcong <br/>
 * 功能描述:用户的操作类
 */
public interface UserMapper {
	
	
	/**
	 * 用户登录操作
	 * 创建日期:2017年9月23日<br/>
	 * 创建用户:yellowcong<br/>
	 * 功能描述:
	 * @param username 用户名
	 * @return
	 */
	User login(String username);
}
