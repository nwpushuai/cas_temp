package com.yellowcong.mybatis.handler;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;

/**
 * 创建日期:2017年12月18日
 * 创建时间:下午11:44:33
 * 创建者    :yellowcong
 * 机能概要:处理Boolean类型的转换
 */
public class BooleanTypeHandler implements TypeHandler{

	public Object getResult(ResultSet arg0, String arg1) throws SQLException {
		//查询，获取到字段
		String str = arg0.getString(arg1);  
        Boolean rt = Boolean.FALSE;  
        if (str.equalsIgnoreCase("Y") || str.equalsIgnoreCase("1")){  
            rt = Boolean.TRUE;  
        }  
        return rt;   
	}

	public Object getResult(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getResult(CallableStatement arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public void setParameter(PreparedStatement arg0, int arg1, Object arg2, JdbcType arg3) throws SQLException {
		// TODO Auto-generated method stub
		
	}

}
