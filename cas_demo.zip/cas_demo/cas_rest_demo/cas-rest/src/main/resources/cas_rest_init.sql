/*
SQLyog v10.2 
MySQL - 5.1.68-community : Database - yellowcong_cas_rest
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`yellowcong_cas_rest` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `yellowcong_cas_rest`;

/*Table structure for table `yellowcong_users` */

DROP TABLE IF EXISTS `yellowcong_users`;

CREATE TABLE `yellowcong_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(32) DEFAULT NULL COMMENT '密码',
  `username` varchar(32) DEFAULT NULL COMMENT '用户名',
  `is_disable` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否禁用',
  `is_locked` tinyint(1) DEFAULT '0' COMMENT '是否上锁',
  `is_expired` tinyint(1) DEFAULT '0' COMMENT '是否过期',
  PRIMARY KEY (`id`,`is_disable`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `yellowcong_users` */

insert  into `yellowcong_users`(`id`,`password`,`username`,`is_disable`,`is_locked`,`is_expired`) values (1,'4748f3d238406505bd50e5accc3a8aa2','yellowcong',0,0,0),(12,'4748f3d238406505bd50e5accc3a8aa2','test',1,0,0),(13,'4748f3d238406505bd50e5accc3a8aa2','test2',0,1,0),(14,'637d1339e213d3ab2777c28e7002df52','doubi',0,0,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
