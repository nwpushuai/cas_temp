-- 开启远程访问 
GRANT ALL PRIVILEGES ON *.*TO 'root'@'%' IDENTIFIED BY 'root' WITH GRANT OPTION;

-- 删除数据库，如果存在这个数据库
DROP DATABASE IF EXISTS yellowcong;

-- 创建数据库
CREATE DATABASE yellowcong;

-- 使用数据库
USE yellowcong;

-- 创建表
CREATE TABLE `yellowcong_users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `age` INT(11) DEFAULT NULL,
  `nick_name` VARCHAR(32) DEFAULT NULL,
  `password` VARCHAR(32) DEFAULT NULL,
  `user_name` VARCHAR(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


-- 插入数据
INSERT INTO yellowcong_users
  (id, age, nick_name, PASSWORD, user_name)
VALUES
  -- 4748f3d238406505bd50e5accc3a8aa2  这个是 doubi 的md5码
  (1, 12, 'yellowocng', '4748f3d238406505bd50e5accc3a8aa2', 'yellowcong'),
  (12, 1314, 'doubi', '4748f3d238406505bd50e5accc3a8aa2', 'test'),
  (13, 1314, 'doubi', '4748f3d238406505bd50e5accc3a8aa2', 'test2'),
  (14, NULL, NULL, 'doubi', 'doubi');