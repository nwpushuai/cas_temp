export OPENGROK_INSTANCE_BASE="/home/nwpushuai/SoftWare/Server/OpenGrok_Sources/Android/Google/aosp" #这是生成源码数据库文件的路径，非源码路径 
export OPENGROK_WEBAPP_NAME="aosp" #自定义webapp name 
export OPENGROK_TOMCAT_BASE="/home/nwpushuai/SoftWare/Server/Tomcat" #改成自己的tomcat路径 
/home/nwpushuai/SoftWare/Server/Opengrok/bin/OpenGrok deploy #不要加sudo,否则环境变量找不到 
/home/nwpushuai/SoftWare/Server/Opengrok/bin/OpenGrok index /home/nwpushuai/Sources/Android/Google/aosp
